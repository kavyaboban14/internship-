from flask import Flask, render_template, request,redirect
import pickle
model_path = 'Models/weekly_sales.pkl'
model = pickle.load(open(model_path, 'rb'))


app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def loadPredict():
    if request.method == 'GET':
       return render_template('signin.html',inc="")
    else:
       email=request.form['email']
       password=request.form['password']
       
       if email=='admin' and password=='admin':
              return redirect('/index')
       return render_template('signin.html',inc="Invalid Credentials")



@app.route('/predict', methods=['GET', 'POST'])
def predict():
    Store = int(request.form['nostore'])
    Dept = int(request.form['dept'])
    IsHoliday = int(request.form['IsHoliday'])
    date = (request.form['week']).split('-')
    date_year = int(date[0])
    date_month = int(date[1])
    date_day = int(date[2])
    res = model.predict(
        [[Store, Dept, IsHoliday, date_year, date_month, date_day]])
    return render_template('pred.html', data=res[0])


@app.route('/chart', methods=['GET', 'POST'])
def chart():
    return render_template('chart.html')


@app.route('/index', methods=['GET', 'POST'])
def index():
    return render_template('index.html')


@app.route('/table', methods=['GET', 'POST'])
def table():
    return render_template('table.html')


@app.route('/etable', methods=['GET', 'POST'])
def etable():
    return render_template('etable.html')


@app.route('/blank', methods=['GET', 'POST'])
def blank():
    return render_template('blank.html')


@app.route('/signin', methods=['GET', 'POST'])
def signin():
    return render_template('signin')


@app.route('/graphset1', methods=['GET', 'POST'])
def graphset1():
    return render_template('graphset1.html')


@app.route('/graphset2', methods=['GET', 'POST'])
def graphset2():
    return render_template('graphset2.html')


@app.route('/graphset3', methods=['GET', 'POST'])
def graphset3():
    return render_template('graphset3.html')


if __name__ == '__main__':
    app.run(debug=True)
